### README

##### Compile

In your bash terminal (Linux/Mac should be OKay Windows Users please use WSL), type 

`sh compile.sh` or `bash compile.sh`

If it doesn't work, you can try

```sh
gcc -o main *.c -Wall -Wextra -Werror -pedantic -lm
```

##### Usage specifications

input filename restrict: `l6_input.txt`

output file name restrict: `l6_output.txt`
