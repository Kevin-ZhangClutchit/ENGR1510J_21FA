#!/bin/bash
gcc -o main *.c -Wall -Wextra -Werror -pedantic -lm